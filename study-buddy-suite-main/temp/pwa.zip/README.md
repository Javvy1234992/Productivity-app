# Student Productivity PWA

A minimalist, offline-first Progressive Web App (PWA) designed for high school students to manage their workload through To-do lists, Calendar, Notes, and Whiteboard modules.

## Features

- **To-do List**: Organize tasks with categories (School/Personal) and due dates
- **Calendar**: Month view with daily task management
- **Notes**: Two-pane editor with folder organization and search
- **Whiteboard**: Canvas-based drawing tool with text, sticky notes, images, and freehand drawing
- **Offline Support**: All data stored locally using IndexedDB via Localforage
- **PWA Installation**: Install as a standalone app on Chromebooks and other devices
- **No Authentication Required**: Complete privacy - all data stays on your device

## Technology Stack

- **Framework**: React 19 with TypeScript
- **Styling**: Tailwind CSS 4
- **Data Storage**: Localforage (IndexedDB wrapper)
- **Canvas**: Fabric.js for whiteboard functionality
- **Date Management**: date-fns
- **Icons**: Lucide React
- **Routing**: Wouter
- **Build Tool**: Vite

## Installation

### Development

1. Clone the repository and navigate to the project directory:
   ```bash
   cd productivity-pwa
   ```

2. Install dependencies:
   ```bash
   pnpm install
   ```

3. Start the development server:
   ```bash
   pnpm dev
   ```

4. Open your browser and navigate to `http://localhost:3000`

### Production Build

1. Build the project:
   ```bash
   pnpm build
   ```

2. Preview the production build:
   ```bash
   pnpm preview
   ```

3. The built files are in the `dist/` directory

## Installation as PWA on Chromebook

### Method 1: Chrome Browser

1. Open the app in Chrome
2. Click the menu icon (⋮) in the top-right corner
3. Select **"Install app"** or **"Create shortcut"**
4. Choose **"Create window"**
5. The app will install as a standalone application

### Method 2: Direct Installation

1. Visit the app URL in Chrome
2. Look for the install prompt at the top of the address bar
3. Click **"Install"**
4. The app will be added to your applications

### First Launch

On first launch, the app will:
- Initialize local storage
- Create default data structures
- Set up the service worker for offline support

## Usage Guide

### Home Page

- View statistics: pending tasks, notes created, last board opened
- Quick action buttons to create new tasks or notes
- Privacy notice confirming all data is stored locally

### To-do List

1. **Filter tasks**: Use category buttons (All, School, Personal)
2. **Add task**: Click the "+" button and fill in details
3. **Edit task**: Right-click on a task and select "Edit task"
4. **Mark complete**: Click the checkbox next to a task
5. **Delete task**: Right-click and select "Delete task"

### Calendar

1. **Navigate months**: Use arrow buttons to move between months
2. **View day**: Click any date to see tasks for that day
3. **Add task**: Click "Add Task" in the right panel
4. **Edit/Delete**: Use the menu options for tasks

### Notes

1. **Create note**: Click "New Note" and choose a folder
2. **Search**: Use the search bar to find notes by title
3. **Filter by folder**: Select a folder from the dropdown
4. **Edit**: Click a note to open it in the editor
5. **Auto-save**: Changes are saved automatically (500ms debounce)
6. **Delete**: Click the trash icon to remove a note

### Whiteboard

1. **Add text**: Click "Text" and place text on the canvas
2. **Add sticky note**: Click "Sticky note" to add a yellow note
3. **Add image**: Click "Image" to upload from your device
4. **Draw**: Click "Draw" to enable freehand drawing
5. **Manipulate objects**: Click and drag to move, use handles to resize
6. **Save**: Click "Save" to persist your work
7. **Clear**: Click "Clear" to start fresh

## Data Storage

All data is stored locally using IndexedDB through the Localforage library:

- **Todos**: Stored with title, due date, category, and completion status
- **Notes**: Stored with title, content, folder, and timestamps
- **Whiteboard Projects**: Canvas data saved as JSON

### Data Structure

```typescript
{
  todos: Todo[],
  notes: Note[],
  boardProjects: BoardProject[],
  currentBoardId?: string,
  userName?: string,
  theme: 'light' | 'dark'
}
```

## Offline Functionality

The app works completely offline:

- **Service Worker**: Caches essential files for offline access
- **Local Storage**: All data persists in IndexedDB
- **No Network Required**: Use the app anywhere, anytime
- **Automatic Sync**: When online, the app continues to work seamlessly

## Accessibility

The app includes:

- ARIA labels on all interactive elements
- Keyboard navigation support (Tab, Enter)
- Semantic HTML structure
- High contrast colors for readability
- Focus indicators on all buttons

## Color Palette

- **Dark Navy** (#071330): Primary text and accents
- **Deep Blue** (#083b69): Active buttons and focus states
- **Muted Blue-Gray** (#0c4160): Secondary accents
- **Soft Slate** (#738fa7): Toolbar and headers
- **Light Cool Gray** (#c3ceda): Navigation background
- **Almost White** (#e7ecf2): Main content background

## Keyboard Shortcuts

- **Tab**: Navigate between elements
- **Enter**: Activate buttons or submit forms
- **Escape**: Close dialogs or cancel operations
- **Delete**: Remove selected items (with confirmation)

## Performance

- **Lighthouse Scores**: Target 90+ for Performance, Accessibility, and Best Practices
- **Bundle Size**: Optimized for fast loading on Chromebooks
- **Offline Ready**: Passes PWA audit requirements
- **Responsive Design**: Works on screens from 768px width and up

## Privacy Statement

**Your data is completely private and secure.**

- All data is stored locally on your device using IndexedDB
- No data is sent to external servers
- No tracking or analytics collection
- No user authentication required
- You have full control over your data
- Delete all data anytime from the menu

## Development Notes

### Project Structure

```
client/
├── public/           # Static assets
│   ├── manifest.json # PWA manifest
│   └── sw.js         # Service worker
├── src/
│   ├── components/   # Reusable components
│   ├── contexts/     # React contexts
│   ├── lib/          # Utility functions and storage
│   ├── pages/        # Page components
│   ├── App.tsx       # Main app component
│   ├── main.tsx      # React entry point
│   └── index.css     # Global styles
```

### Adding New Features

1. Create storage functions in `lib/storage.ts`
2. Add UI components in `components/`
3. Create page in `pages/`
4. Add route in `App.tsx`
5. Update navigation in `components/Navigation.tsx`

### Testing

Run TypeScript checks:
```bash
pnpm check
```

Format code:
```bash
pnpm format
```

## Browser Support

- Chrome/Chromium 90+
- Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers with PWA support

## Troubleshooting

### App won't load offline
- Check that the service worker is registered (DevTools > Application > Service Workers)
- Ensure the app was loaded at least once while online
- Clear browser cache and reload

### Data not saving
- Check browser's IndexedDB storage quota
- Ensure Localforage is initialized
- Check browser console for errors

### Whiteboard canvas issues
- Ensure Fabric.js is loaded correctly
- Try refreshing the page
- Check that your browser supports HTML5 Canvas

## Future Enhancements

- Dark mode theme toggle
- User name personalization
- Export/import data functionality
- Collaborative features
- Mobile app versions
- Cloud sync option (optional)

## License

MIT

## Support

For issues or feature requests, please check the browser console for error messages and ensure all dependencies are properly installed.

---

**Made for students, by students. Keep your productivity local and private.**
