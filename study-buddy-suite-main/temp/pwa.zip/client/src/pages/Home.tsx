import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { Plus } from 'lucide-react';
import { getStats } from '@/lib/storage';
import { useApp } from '@/contexts/AppContext';

/**
 * Home Page
 * Design: Minimalist welcome page with statistics and quick actions
 * - Greeting message
 * - Stats: pending tasks, notes created, last board opened
 * - Quick action buttons
 */

interface Stats {
  pendingTodos: number;
  notesCount: number;
  lastBoard: string | null;
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [stats, setStats] = useState<Stats>({
    pendingTodos: 0,
    notesCount: 0,
    lastBoard: null,
  });
  const { appState } = useApp();

  useEffect(() => {
    const loadStats = async () => {
      const data = await getStats();
      setStats(data);
    };
    loadStats();
  }, [appState]);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-4 py-12">
        {/* Greeting Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            {getGreeting()}!
          </h1>
          <p className="text-muted-foreground">
            {appState?.userName ? `Welcome back, ${appState.userName}` : 'Welcome to your productivity hub'}
          </p>
        </div>

        {/* Statistics Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Pending Tasks */}
          <div className="bg-card border border-border rounded-lg p-6 shadow-sm">
            <div className="text-sm text-muted-foreground mb-2">Pending tasks</div>
            <div className="text-3xl font-bold text-accent">{stats.pendingTodos}</div>
          </div>

          {/* Notes Created */}
          <div className="bg-card border border-border rounded-lg p-6 shadow-sm">
            <div className="text-sm text-muted-foreground mb-2">Notes created</div>
            <div className="text-3xl font-bold text-accent">{stats.notesCount}</div>
          </div>

          {/* Last Board */}
          <div className="bg-card border border-border rounded-lg p-6 shadow-sm">
            <div className="text-sm text-muted-foreground mb-2">Last board opened</div>
            <div className="text-lg font-semibold text-foreground truncate">
              {stats.lastBoard ? `"${stats.lastBoard}"` : 'None yet'}
            </div>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={() => setLocation('/todos')}
            className="flex items-center justify-center gap-2 bg-accent text-accent-foreground px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity shadow-sm"
            aria-label="Create new task"
          >
            <Plus className="w-5 h-5" />
            New Task
          </button>
          <button
            onClick={() => setLocation('/notes')}
            className="flex items-center justify-center gap-2 bg-accent text-accent-foreground px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity shadow-sm"
            aria-label="Create new note"
          >
            <Plus className="w-5 h-5" />
            New Note
          </button>
        </div>

        {/* Info Section */}
        <div className="mt-12 p-6 bg-muted rounded-lg border border-border">
          <h2 className="text-lg font-semibold text-foreground mb-2">💡 Tip</h2>
          <p className="text-muted-foreground">
            All your data is stored locally on your device. No internet connection required. Your privacy is protected.
          </p>
        </div>
      </div>
    </div>
  );
}
