import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, MoreVertical, Trash2 } from 'lucide-react';
import { getTodos, addTodo, updateTodo, deleteTodo, Todo } from '@/lib/storage';
import { useApp } from '@/contexts/AppContext';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay } from 'date-fns';

/**
 * Calendar Page
 * Design: Month grid view with daily task list on date click
 * - Month navigation with arrows
 * - Click date to see tasks for that day
 * - Add/edit/delete tasks for specific day
 */

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [todos, setTodos] = useState<Todo[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newTodo, setNewTodo] = useState({
    title: '',
    category: 'School' as const,
  });
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; todoId: string } | null>(null);
  const { appState } = useApp();

  useEffect(() => {
    const loadTodos = async () => {
      const data = await getTodos();
      setTodos(data);
    };
    loadTodos();
  }, [appState]);

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getDaysGrid = () => {
    const firstDay = monthStart.getDay();
    const days = [];
    
    // Add empty cells for days before month starts
    for (let i = 0; i < firstDay; i++) {
      days.push(null);
    }
    
    // Add days of the month
    daysInMonth.forEach(day => days.push(day));
    
    return days;
  };

  const getTasksForDate = (date: Date) => {
    return todos.filter(todo => {
      if (!todo.dueDate) return false;
      const todoDate = new Date(todo.dueDate);
      return isSameDay(todoDate, date);
    });
  };

  const selectedDateTasks = selectedDate ? getTasksForDate(selectedDate) : [];

  const handleAddTodo = async () => {
    if (!newTodo.title.trim() || !selectedDate) return;

    try {
      const todo = await addTodo({
        title: newTodo.title,
        dueDate: format(selectedDate, 'yyyy-MM-dd'),
        category: newTodo.category,
        done: false,
      });
      setTodos([...todos, todo]);
      setNewTodo({ title: '', category: 'School' });
      setIsAdding(false);
    } catch (error) {
      console.error('Failed to add todo:', error);
    }
  };

  const handleToggleTodo = async (id: string, done: boolean) => {
    try {
      const updated = await updateTodo(id, { done: !done });
      if (updated) {
        setTodos(todos.map(t => (t.id === id ? updated : t)));
      }
    } catch (error) {
      console.error('Failed to update todo:', error);
    }
  };

  const handleDeleteTodo = async (id: string) => {
    try {
      await deleteTodo(id);
      setTodos(todos.filter(t => t.id !== id));
      setContextMenu(null);
    } catch (error) {
      console.error('Failed to delete todo:', error);
    }
  };

  const daysGrid = getDaysGrid();
  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar View */}
          <div className="lg:col-span-2">
            <div className="bg-card border border-border rounded-lg p-6">
              {/* Month Navigation */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-foreground">
                  {format(currentDate, 'MMMM yyyy')}
                </h2>
                <div className="flex gap-2">
                  <button
                    onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1))}
                    className="p-2 hover:bg-muted rounded-lg transition-colors"
                    aria-label="Previous month"
                  >
                    <ChevronLeft className="w-5 h-5 text-foreground" />
                  </button>
                  <button
                    onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1))}
                    className="p-2 hover:bg-muted rounded-lg transition-colors"
                    aria-label="Next month"
                  >
                    <ChevronRight className="w-5 h-5 text-foreground" />
                  </button>
                </div>
              </div>

              {/* Weekday Headers */}
              <div className="grid grid-cols-7 gap-2 mb-4">
                {weekDays.map(day => (
                  <div key={day} className="text-center font-semibold text-muted-foreground text-sm py-2">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {daysGrid.map((day, index) => (
                  <div
                    key={index}
                    className={`aspect-square p-2 rounded-lg border cursor-pointer transition-colors ${
                      !day
                        ? 'bg-muted border-transparent'
                        : isSameDay(day, selectedDate || new Date(-1))
                        ? 'bg-accent text-accent-foreground border-accent'
                        : 'bg-background border-border hover:bg-muted'
                    }`}
                    onClick={() => day && setSelectedDate(day)}
                  >
                    {day && (
                      <div className="text-sm font-semibold">{format(day, 'd')}</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Tasks for Selected Date */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-xl font-bold text-foreground mb-4">
              {selectedDate ? format(selectedDate, 'dd MMMM yyyy') : 'Select a date'}
            </h3>

            {selectedDate && (
              <>
                {/* Tasks List */}
                <div className="space-y-2 mb-4">
                  {selectedDateTasks.length === 0 ? (
                    <p className="text-muted-foreground text-sm">No tasks for this day</p>
                  ) : (
                    selectedDateTasks.map(todo => (
                      <div key={todo.id} className="flex items-center gap-2 p-2 hover:bg-muted rounded-lg group">
                        <input
                          type="checkbox"
                          checked={todo.done}
                          onChange={() => handleToggleTodo(todo.id, todo.done)}
                          className="w-4 h-4 cursor-pointer"
                          aria-label={`Mark "${todo.title}" as done`}
                        />
                        <span className={`flex-1 text-sm ${
                          todo.done ? 'line-through text-muted-foreground' : 'text-foreground'
                        }`}>
                          {todo.title}
                        </span>
                        <button
                          onClick={e => {
                            e.preventDefault();
                            setContextMenu({ x: e.clientX, y: e.clientY, todoId: todo.id });
                          }}
                          className="p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          aria-label="More options"
                        >
                          <MoreVertical className="w-3 h-3 text-foreground" />
                        </button>
                      </div>
                    ))
                  )}
                </div>

                {/* Add Task Form */}
                {isAdding ? (
                  <div className="space-y-2">
                    <input
                      type="text"
                      placeholder="Task title"
                      value={newTodo.title}
                      onChange={e => setNewTodo({ ...newTodo, title: e.target.value })}
                      className="w-full px-2 py-1 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent text-sm"
                      autoFocus
                      aria-label="Task title"
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={handleAddTodo}
                        className="flex-1 bg-accent text-accent-foreground px-2 py-1 rounded-lg font-medium text-sm hover:opacity-90 transition-opacity"
                      >
                        Add
                      </button>
                      <button
                        onClick={() => {
                          setIsAdding(false);
                          setNewTodo({ title: '', category: 'School' });
                        }}
                        className="flex-1 bg-muted text-foreground px-2 py-1 rounded-lg font-medium text-sm hover:bg-muted/80 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsAdding(true)}
                    className="w-full flex items-center justify-center gap-1 bg-accent text-accent-foreground px-2 py-1 rounded-lg font-medium text-sm hover:opacity-90 transition-opacity"
                    aria-label="Add task"
                  >
                    <Plus className="w-4 h-4" />
                    Add Task
                  </button>
                )}
              </>
            )}

            {/* Context Menu */}
            {contextMenu && (
              <div
                className="fixed bg-card border border-border rounded-lg shadow-lg z-50 overflow-hidden"
                style={{
                  left: `${contextMenu.x}px`,
                  top: `${contextMenu.y}px`,
                }}
              >
                <button
                  onClick={() => handleDeleteTodo(contextMenu.todoId)}
                  className="w-full px-3 py-2 text-left hover:bg-destructive hover:text-destructive-foreground transition-colors flex items-center gap-2 text-foreground text-sm"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
