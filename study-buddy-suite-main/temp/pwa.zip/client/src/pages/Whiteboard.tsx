import { useEffect, useRef, useState } from 'react';
import { Type, Sticker, Image as ImageIcon, Pen, Trash2, Save } from 'lucide-react';
import { Canvas, Textbox, Rect, FabricImage } from 'fabric';
import { getBoardProjects, addBoardProject, updateBoardProject } from '@/lib/storage';
import { useApp } from '@/contexts/AppContext';

/**
 * Whiteboard Page
 * Design: Large canvas with dot-grid background and toolbar
 * - Toolbar: Text, Sticky note, Image, Draw
 * - Dot-grid background
 * - Auto-save canvas to Localforage
 * - Drag and resize objects
 */

export default function WhiteboardPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricCanvasRef = useRef<Canvas | null>(null);
  const [tool, setTool] = useState<'text' | 'sticky' | 'image' | 'draw' | null>(null);
  const [boardId, setBoardId] = useState<string | null>(null);
  const { appState } = useApp();

  useEffect(() => {
    const initCanvas = async () => {
      if (!canvasRef.current) return;

      // Initialize Fabric canvas
      const fabricCanvas = new Canvas(canvasRef.current, {
        width: window.innerWidth - 20,
        height: window.innerHeight - 100,
        backgroundColor: '#e7ecf2',
      });

      // Add dot grid background
      const gridSize = 20;
      const ctx = fabricCanvas.getContext();
      ctx.fillStyle = '#0c4160';
      for (let x = 0; x < fabricCanvas.width!; x += gridSize) {
        for (let y = 0; y < fabricCanvas.height!; y += gridSize) {
          ctx.fillRect(x, y, 1, 1);
        }
      }

      fabricCanvasRef.current = fabricCanvas;

      // Load existing board or create new one
      const boards = await getBoardProjects();
      let board = boards[boards.length - 1];

      if (!board) {
        board = await addBoardProject({
          name: `Board ${new Date().toLocaleDateString()}`,
          canvasData: JSON.stringify(fabricCanvas.toJSON()),
        });
      }

      setBoardId(board.id);

      // Load canvas data if exists
      if (board.canvasData) {
        try {
          const data = JSON.parse(board.canvasData);
          fabricCanvas.loadFromJSON(data, () => {
            fabricCanvas.renderAll();
          });
        } catch (error) {
          console.error('Failed to load canvas data:', error);
        }
      }

      // Handle window resize
      const handleResize = () => {
        fabricCanvas.setDimensions({
          width: window.innerWidth - 20,
          height: window.innerHeight - 100,
        });
        fabricCanvas.renderAll();
      };

      window.addEventListener('resize', handleResize);

      return () => {
        window.removeEventListener('resize', handleResize);
        fabricCanvas.dispose();
      };
    };

    initCanvas();
  }, []);

  const handleAddText = () => {
    if (!fabricCanvasRef.current) return;

    const text = new Textbox('Click to edit', {
      left: 100,
      top: 100,
      fontSize: 20,
      fill: '#071330',
      editable: true,
    });

    fabricCanvasRef.current.add(text);
    fabricCanvasRef.current.setActiveObject(text);
    fabricCanvasRef.current.renderAll();
    setTool(null);
  };

  const handleAddSticky = () => {
    if (!fabricCanvasRef.current) return;

    const rect = new Rect({
      left: 100,
      top: 100,
      width: 150,
      height: 150,
      fill: '#ffd700',
      stroke: '#c3ceda',
      strokeWidth: 2,
    });

    const text = new Textbox('Note', {
      left: 110,
      top: 110,
      fontSize: 16,
      fill: '#071330',
      editable: true,
    });

    fabricCanvasRef.current.add(rect);
    fabricCanvasRef.current.add(text);
    fabricCanvasRef.current.setActiveObject(text);
    fabricCanvasRef.current.renderAll();
    setTool(null);
  };

  const handleAddImage = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async e => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file || !fabricCanvasRef.current) return;

      const reader = new FileReader();
      reader.onload = async event => {
        try {
          const imgData = event.target?.result as string;
          const img = new Image();
          img.onload = () => {
            const fabricImg = new FabricImage(img, {
              left: 100,
              top: 100,
              scaleX: 0.5,
              scaleY: 0.5,
            });
            fabricCanvasRef.current?.add(fabricImg);
            fabricCanvasRef.current?.renderAll();
          };
          img.src = imgData;
        } catch (error) {
          console.error('Failed to add image:', error);
        }
      };
      reader.readAsDataURL(file);
    };
    input.click();
    setTool(null);
  };

  const handleDraw = () => {
    if (!fabricCanvasRef.current) return;
    setTool(tool === 'draw' ? null : 'draw');
    fabricCanvasRef.current.isDrawingMode = tool === 'draw' ? false : true;
    if (fabricCanvasRef.current.isDrawingMode && fabricCanvasRef.current.freeDrawingBrush) {
      fabricCanvasRef.current.freeDrawingBrush.color = '#071330';
      fabricCanvasRef.current.freeDrawingBrush.width = 3;
    }
  };

  const handleClear = () => {
    if (!fabricCanvasRef.current) return;
    if (window.confirm('Clear the entire canvas?')) {
      fabricCanvasRef.current.clear();
      fabricCanvasRef.current.renderAll();
    }
  };

  const handleSave = async () => {
    if (!fabricCanvasRef.current || !boardId) return;

    try {
      const canvasData = JSON.stringify(fabricCanvasRef.current.toJSON());
      await updateBoardProject(boardId, { canvasData });
      alert('Board saved successfully!');
    } catch (error) {
      console.error('Failed to save board:', error);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Toolbar */}
      <div className="bg-secondary border-b border-border p-4 flex gap-2 flex-wrap">
        <button
          onClick={handleAddText}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            tool === 'text'
              ? 'bg-accent text-accent-foreground'
              : 'bg-muted text-foreground hover:bg-muted/80'
          }`}
          aria-label="Add text"
        >
          <Type className="w-5 h-5" />
          Text
        </button>
        <button
          onClick={handleAddSticky}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            tool === 'sticky'
              ? 'bg-accent text-accent-foreground'
              : 'bg-muted text-foreground hover:bg-muted/80'
          }`}
          aria-label="Add sticky note"
        >
          <Sticker className="w-5 h-5" />
          Sticky note
        </button>
        <button
          onClick={handleAddImage}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            tool === 'image'
              ? 'bg-accent text-accent-foreground'
              : 'bg-muted text-foreground hover:bg-muted/80'
          }`}
          aria-label="Add image"
        >
          <ImageIcon className="w-5 h-5" />
          Image
        </button>
        <button
          onClick={handleDraw}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            tool === 'draw'
              ? 'bg-accent text-accent-foreground'
              : 'bg-muted text-foreground hover:bg-muted/80'
          }`}
          aria-label="Draw"
        >
          <Pen className="w-5 h-5" />
          Draw
        </button>
        <button
          onClick={handleSave}
          className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium bg-accent text-accent-foreground hover:opacity-90 transition-opacity ml-auto"
          aria-label="Save board"
        >
          <Save className="w-5 h-5" />
          Save
        </button>
        <button
          onClick={handleClear}
          className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium bg-destructive text-destructive-foreground hover:opacity-90 transition-opacity"
          aria-label="Clear canvas"
        >
          <Trash2 className="w-5 h-5" />
          Clear
        </button>
      </div>

      {/* Canvas */}
      <div className="flex-1 overflow-hidden">
        <canvas ref={canvasRef} className="block" />
      </div>
    </div>
  );
}
