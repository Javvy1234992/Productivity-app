import { useEffect, useState } from 'react';
import { Plus, Trash2, Edit2, MoreVertical } from 'lucide-react';
import { getTodos, addTodo, updateTodo, deleteTodo, Todo } from '@/lib/storage';
import { useApp } from '@/contexts/AppContext';

/**
 * To-do List Page
 * Design: Minimalist task list with category filtering
 * - Category filter: All, School, Personal
 * - Task list with title, date, checkbox
 * - Right-click context menu for edit/delete
 * - Add button to create new tasks
 */

type CategoryFilter = 'All' | 'School' | 'Personal';

interface EditingTodo {
  id: string;
  title: string;
  dueDate: string;
  category: 'School' | 'Personal';
}

export default function TodoList() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [filter, setFilter] = useState<CategoryFilter>('All');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTodo, setEditingTodo] = useState<EditingTodo | null>(null);
  const [newTodo, setNewTodo] = useState({
    title: '',
    dueDate: '',
    category: 'School' as const,
  });
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; todoId: string } | null>(null);
  const { appState } = useApp();

  useEffect(() => {
    const loadTodos = async () => {
      const data = await getTodos();
      setTodos(data);
    };
    loadTodos();
  }, [appState]);

  const filteredTodos = todos.filter(todo => {
    if (filter === 'All') return true;
    return todo.category === filter;
  });

  const handleAddTodo = async () => {
    if (!newTodo.title.trim()) return;

    try {
      const todo = await addTodo({
        title: newTodo.title,
        dueDate: newTodo.dueDate,
        category: newTodo.category,
        done: false,
      });
      setTodos([...todos, todo]);
      setNewTodo({ title: '', dueDate: '', category: 'School' });
      setIsAdding(false);
    } catch (error) {
      console.error('Failed to add todo:', error);
    }
  };

  const handleToggleTodo = async (id: string, done: boolean) => {
    try {
      const updated = await updateTodo(id, { done: !done });
      if (updated) {
        setTodos(todos.map(t => (t.id === id ? updated : t)));
      }
    } catch (error) {
      console.error('Failed to update todo:', error);
    }
  };

  const handleDeleteTodo = async (id: string) => {
    try {
      await deleteTodo(id);
      setTodos(todos.filter(t => t.id !== id));
      setContextMenu(null);
    } catch (error) {
      console.error('Failed to delete todo:', error);
    }
  };

  const handleEditTodo = async () => {
    if (!editingTodo || !editingTodo.title.trim()) return;

    try {
      const updated = await updateTodo(editingTodo.id, {
        title: editingTodo.title,
        dueDate: editingTodo.dueDate,
        category: editingTodo.category,
      });
      if (updated) {
        setTodos(todos.map(t => (t.id === editingTodo.id ? updated : t)));
        setEditingId(null);
        setEditingTodo(null);
      }
    } catch (error) {
      console.error('Failed to update todo:', error);
    }
  };

  const startEditing = (todo: Todo) => {
    setEditingId(todo.id);
    setEditingTodo({
      id: todo.id,
      title: todo.title,
      dueDate: todo.dueDate,
      category: todo.category,
    });
    setContextMenu(null);
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-foreground">To-do List</h1>
        </div>

        {/* Category Filter */}
        <div className="bg-secondary rounded-lg p-4 mb-6 flex gap-2 flex-wrap">
          {(['All', 'School', 'Personal'] as const).map(category => (
            <button
              key={category}
              onClick={() => setFilter(category)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                filter === category
                  ? 'bg-accent text-accent-foreground'
                  : 'bg-muted text-foreground hover:bg-muted/80'
              }`}
              aria-pressed={filter === category}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Todo List */}
        <div className="space-y-2 mb-6">
          {filteredTodos.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>No tasks yet. Create one to get started!</p>
            </div>
          ) : (
            filteredTodos.map(todo => (
              <div key={todo.id} className="task-item flex items-center gap-4 relative group">
                <input
                  type="checkbox"
                  checked={todo.done}
                  onChange={() => handleToggleTodo(todo.id, todo.done)}
                  className="w-5 h-5 cursor-pointer"
                  aria-label={`Mark "${todo.title}" as done`}
                />
                <div className="flex-1">
                  <p className={`text-foreground ${
                    todo.done ? 'line-through text-muted-foreground' : ''
                  }`}>
                    {todo.title}
                  </p>
                </div>
                <span className="text-sm text-muted-foreground">{formatDate(todo.dueDate)}</span>
                <button
                  onClick={e => {
                    e.preventDefault();
                    setContextMenu({ x: e.clientX, y: e.clientY, todoId: todo.id });
                  }}
                  className="p-2 hover:bg-muted rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                  aria-label="More options"
                >
                  <MoreVertical className="w-4 h-4 text-foreground" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Add Todo Form */}
        {isAdding ? (
          <div className="bg-card border border-border rounded-lg p-4 space-y-4">
            <input
              type="text"
              placeholder="Task title"
              value={newTodo.title}
              onChange={e => setNewTodo({ ...newTodo, title: e.target.value })}
              className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
              autoFocus
              aria-label="Task title"
            />
            <div className="grid grid-cols-2 gap-4">
              <input
                type="date"
                value={newTodo.dueDate}
                onChange={e => setNewTodo({ ...newTodo, dueDate: e.target.value })}
                className="px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                aria-label="Due date"
              />
              <select
                value={newTodo.category}
                onChange={e => setNewTodo({ ...newTodo, category: e.target.value as any })}
                className="px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                aria-label="Category"
              >
                <option value="School">School</option>
                <option value="Personal">Personal</option>
              </select>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleAddTodo}
                className="flex-1 bg-accent text-accent-foreground px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity"
              >
                Add Task
              </button>
              <button
                onClick={() => {
                  setIsAdding(false);
                  setNewTodo({ title: '', dueDate: '', category: 'School' });
                }}
                className="flex-1 bg-muted text-foreground px-4 py-2 rounded-lg font-medium hover:bg-muted/80 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setIsAdding(true)}
            className="w-full flex items-center justify-center gap-2 bg-accent text-accent-foreground px-4 py-3 rounded-lg font-medium hover:opacity-90 transition-opacity"
            aria-label="Add new task"
          >
            <Plus className="w-5 h-5" />
            Add Task
          </button>
        )}

        {/* Edit Modal */}
        {editingId && editingTodo && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-card border border-border rounded-lg p-6 max-w-md w-full space-y-4">
              <h2 className="text-xl font-bold text-foreground">Edit Task</h2>
              <input
                type="text"
                value={editingTodo.title}
                onChange={e => setEditingTodo({ ...editingTodo, title: e.target.value })}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                aria-label="Task title"
              />
              <input
                type="date"
                value={editingTodo.dueDate}
                onChange={e => setEditingTodo({ ...editingTodo, dueDate: e.target.value })}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                aria-label="Due date"
              />
              <select
                value={editingTodo.category}
                onChange={e => setEditingTodo({ ...editingTodo, category: e.target.value as any })}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                aria-label="Category"
              >
                <option value="School">School</option>
                <option value="Personal">Personal</option>
              </select>
              <div className="flex gap-2">
                <button
                  onClick={handleEditTodo}
                  className="flex-1 bg-accent text-accent-foreground px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setEditingId(null);
                    setEditingTodo(null);
                  }}
                  className="flex-1 bg-muted text-foreground px-4 py-2 rounded-lg font-medium hover:bg-muted/80 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Context Menu */}
        {contextMenu && (
          <div
            className="fixed bg-card border border-border rounded-lg shadow-lg z-50 overflow-hidden"
            style={{
              left: `${contextMenu.x}px`,
              top: `${contextMenu.y}px`,
            }}
          >
            <button
              onClick={() => {
                const todo = todos.find(t => t.id === contextMenu.todoId);
                if (todo) startEditing(todo);
              }}
              className="w-full px-4 py-2 text-left hover:bg-muted transition-colors flex items-center gap-2 text-foreground text-sm"
            >
              <Edit2 className="w-4 h-4" />
              Edit task
            </button>
            <button
              onClick={() => handleDeleteTodo(contextMenu.todoId)}
              className="w-full px-4 py-2 text-left hover:bg-destructive hover:text-destructive-foreground transition-colors flex items-center gap-2 text-foreground text-sm"
            >
              <Trash2 className="w-4 h-4" />
              Delete task
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
