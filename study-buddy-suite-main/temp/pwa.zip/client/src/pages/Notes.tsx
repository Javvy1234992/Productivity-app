import { useEffect, useState } from 'react';
import { Plus, Trash2, Search, FolderOpen } from 'lucide-react';
import { getNotes, addNote, updateNote, deleteNote, Note } from '@/lib/storage';
import { useApp } from '@/contexts/AppContext';

/**
 * Notes Page
 * Design: Two-pane layout with sidebar and editor
 * - Sidebar: list of notes and folders
 * - Search bar to filter notes
 * - Folder filter dropdown
 * - Main editor pane for note content
 * - Auto-save on typing (500ms debounce)
 */

export default function NotesPage() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteFolder, setNewNoteFolder] = useState('General');
  const [editingContent, setEditingContent] = useState('');
  const [saveTimeout, setSaveTimeout] = useState<NodeJS.Timeout | null>(null);
  const { appState } = useApp();

  useEffect(() => {
    const loadNotes = async () => {
      const data = await getNotes();
      setNotes(data);
    };
    loadNotes();
  }, [appState]);

  // Get unique folders
  const folders = Array.from(new Set(notes.map(n => n.folder)));
  const allFolders = ['General', ...folders.filter(f => f !== 'General')];

  // Filter notes
  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFolder = !selectedFolder || note.folder === selectedFolder;
    return matchesSearch && matchesFolder;
  });

  const selectedNote = notes.find(n => n.id === selectedNoteId);

  // Auto-save on content change
  useEffect(() => {
    if (selectedNote && editingContent !== selectedNote.content) {
      if (saveTimeout) clearTimeout(saveTimeout);

      const timeout = setTimeout(async () => {
        try {
          await updateNote(selectedNote.id, { content: editingContent });
          const updated = await getNotes();
          setNotes(updated);
        } catch (error) {
          console.error('Failed to save note:', error);
        }
      }, 500);

      setSaveTimeout(timeout);
    }

    return () => {
      if (saveTimeout) clearTimeout(saveTimeout);
    };
  }, [editingContent, selectedNote]);

  const handleAddNote = async () => {
    if (!newNoteTitle.trim()) return;

    try {
      const note = await addNote({
        title: newNoteTitle,
        content: '',
        folder: newNoteFolder,
      });
      setNotes([...notes, note]);
      setSelectedNoteId(note.id);
      setEditingContent('');
      setNewNoteTitle('');
      setIsAdding(false);
    } catch (error) {
      console.error('Failed to add note:', error);
    }
  };

  const handleDeleteNote = async (id: string) => {
    try {
      await deleteNote(id);
      setNotes(notes.filter(n => n.id !== id));
      if (selectedNoteId === id) {
        setSelectedNoteId(null);
        setEditingContent('');
      }
    } catch (error) {
      console.error('Failed to delete note:', error);
    }
  };

  const handleSelectNote = (id: string) => {
    setSelectedNoteId(id);
    const note = notes.find(n => n.id === id);
    if (note) {
      setEditingContent(note.content);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="flex h-screen flex-col md:flex-row">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-secondary border-r border-border p-4 flex flex-col">
          {/* Search Bar */}
          <div className="mb-4 relative">
            <Search className="absolute left-2 top-2.5 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search note"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent text-sm"
              aria-label="Search notes"
            />
          </div>

          {/* Folder Filter */}
          <div className="mb-4">
            <select
              value={selectedFolder || ''}
              onChange={e => setSelectedFolder(e.target.value || null)}
              className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent text-sm"
              aria-label="Filter by folder"
            >
              <option value="">All Folders</option>
              {allFolders.map(folder => (
                <option key={folder} value={folder}>
                  {folder}
                </option>
              ))}
            </select>
          </div>

          {/* Notes List */}
          <div className="flex-1 overflow-y-auto space-y-1 mb-4">
            {filteredNotes.length === 0 ? (
              <p className="text-muted-foreground text-sm">No notes found</p>
            ) : (
              filteredNotes.map(note => (
                <button
                  key={note.id}
                  onClick={() => handleSelectNote(note.id)}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-colors text-sm ${
                    selectedNoteId === note.id
                      ? 'bg-accent text-accent-foreground'
                      : 'hover:bg-muted text-foreground'
                  }`}
                  aria-current={selectedNoteId === note.id ? 'page' : undefined}
                >
                  <div className="font-medium truncate">{note.title}</div>
                  <div className="text-xs opacity-75 truncate">{note.folder}</div>
                </button>
              ))
            )}
          </div>

          {/* Add Note Button */}
          {isAdding ? (
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Note title"
                value={newNoteTitle}
                onChange={e => setNewNoteTitle(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent text-sm"
                autoFocus
                aria-label="Note title"
              />
              <select
                value={newNoteFolder}
                onChange={e => setNewNoteFolder(e.target.value)}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent text-sm"
                aria-label="Folder"
              >
                {allFolders.map(folder => (
                  <option key={folder} value={folder}>
                    {folder}
                  </option>
                ))}
              </select>
              <div className="flex gap-2">
                <button
                  onClick={handleAddNote}
                  className="flex-1 bg-accent text-accent-foreground px-3 py-2 rounded-lg font-medium text-sm hover:opacity-90 transition-opacity"
                >
                  Create
                </button>
                <button
                  onClick={() => {
                    setIsAdding(false);
                    setNewNoteTitle('');
                  }}
                  className="flex-1 bg-muted text-foreground px-3 py-2 rounded-lg font-medium text-sm hover:bg-muted/80 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setIsAdding(true)}
              className="w-full flex items-center justify-center gap-2 bg-accent text-accent-foreground px-3 py-2 rounded-lg font-medium text-sm hover:opacity-90 transition-opacity"
              aria-label="Add new note"
            >
              <Plus className="w-4 h-4" />
              New Note
            </button>
          )}
        </div>

        {/* Main Editor */}
        <div className="flex-1 flex flex-col bg-background">
          {selectedNote ? (
            <>
              {/* Header */}
              <div className="border-b border-border p-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FolderOpen className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <h2 className="text-lg font-bold text-foreground">{selectedNote.title}</h2>
                    <p className="text-sm text-muted-foreground">{selectedNote.folder}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleDeleteNote(selectedNote.id)}
                  className="p-2 hover:bg-destructive hover:text-destructive-foreground rounded-lg transition-colors"
                  aria-label="Delete note"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>

              {/* Editor */}
              <textarea
                value={editingContent}
                onChange={e => setEditingContent(e.target.value)}
                className="flex-1 p-4 bg-background text-foreground placeholder-muted-foreground focus:outline-none resize-none"
                placeholder="Start typing..."
                aria-label="Note content"
              />
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <p>Select a note to view or edit</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
