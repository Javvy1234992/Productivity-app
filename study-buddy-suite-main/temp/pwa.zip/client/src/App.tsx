import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AppProvider } from "./contexts/AppContext";
import Navigation from "./components/Navigation";
import Home from "./pages/Home";
import TodoList from "./pages/TodoList";
import CalendarPage from "./pages/Calendar";
import NotesPage from "./pages/Notes";
import WhiteboardPage from "./pages/Whiteboard";


function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/todos" component={TodoList} />
      <Route path="/calendar" component={CalendarPage} />
      <Route path="/notes" component={NotesPage} />
      <Route path="/board" component={WhiteboardPage} />
      <Route path="/404" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <AppProvider>
          <TooltipProvider>
            <Toaster />
            <Navigation />
            <Router />
          </TooltipProvider>
        </AppProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
