import localforage from 'localforage';

// Initialize localforage stores
localforage.config({
  name: 'ProductivityPWA',
  version: 1.0,
  storeName: 'app_data',
});

export interface Todo {
  id: string;
  title: string;
  dueDate: string;
  category: 'School' | 'Personal';
  done: boolean;
  createdAt: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  folder: string;
  createdAt: string;
  updatedAt: string;
}

export interface BoardProject {
  id: string;
  name: string;
  canvasData: string; // JSON stringified fabric.js canvas
  createdAt: string;
  updatedAt: string;
}

export interface AppState {
  todos: Todo[];
  notes: Note[];
  boardProjects: BoardProject[];
  currentBoardId?: string;
  userName?: string;
  theme: 'light' | 'dark';
}

const STORAGE_KEY = 'app_state';

// Initialize default state
const defaultState: AppState = {
  todos: [],
  notes: [],
  boardProjects: [],
  theme: 'light',
};

export async function initializeStorage() {
  const existing = await localforage.getItem<AppState>(STORAGE_KEY);
  if (!existing) {
    await localforage.setItem(STORAGE_KEY, defaultState);
  }
  return existing || defaultState;
}

export async function getAppState(): Promise<AppState> {
  const state = await localforage.getItem<AppState>(STORAGE_KEY);
  return state || defaultState;
}

export async function updateAppState(updates: Partial<AppState>) {
  const current = await getAppState();
  const updated = { ...current, ...updates };
  await localforage.setItem(STORAGE_KEY, updated);
  return updated;
}

// Todo operations
export async function addTodo(todo: Omit<Todo, 'id' | 'createdAt'>): Promise<Todo> {
  const state = await getAppState();
  const newTodo: Todo = {
    ...todo,
    id: `todo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    createdAt: new Date().toISOString(),
  };
  state.todos.push(newTodo);
  await localforage.setItem(STORAGE_KEY, state);
  return newTodo;
}

export async function updateTodo(id: string, updates: Partial<Todo>): Promise<Todo | null> {
  const state = await getAppState();
  const todo = state.todos.find(t => t.id === id);
  if (!todo) return null;
  Object.assign(todo, updates);
  await localforage.setItem(STORAGE_KEY, state);
  return todo;
}

export async function deleteTodo(id: string): Promise<boolean> {
  const state = await getAppState();
  const index = state.todos.findIndex(t => t.id === id);
  if (index === -1) return false;
  state.todos.splice(index, 1);
  await localforage.setItem(STORAGE_KEY, state);
  return true;
}

export async function getTodos(): Promise<Todo[]> {
  const state = await getAppState();
  return state.todos;
}

// Note operations
export async function addNote(note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>): Promise<Note> {
  const state = await getAppState();
  const now = new Date().toISOString();
  const newNote: Note = {
    ...note,
    id: `note_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    createdAt: now,
    updatedAt: now,
  };
  state.notes.push(newNote);
  await localforage.setItem(STORAGE_KEY, state);
  return newNote;
}

export async function updateNote(id: string, updates: Partial<Note>): Promise<Note | null> {
  const state = await getAppState();
  const note = state.notes.find(n => n.id === id);
  if (!note) return null;
  Object.assign(note, { ...updates, updatedAt: new Date().toISOString() });
  await localforage.setItem(STORAGE_KEY, state);
  return note;
}

export async function deleteNote(id: string): Promise<boolean> {
  const state = await getAppState();
  const index = state.notes.findIndex(n => n.id === id);
  if (index === -1) return false;
  state.notes.splice(index, 1);
  await localforage.setItem(STORAGE_KEY, state);
  return true;
}

export async function getNotes(): Promise<Note[]> {
  const state = await getAppState();
  return state.notes;
}

// Board operations
export async function addBoardProject(
  project: Omit<BoardProject, 'id' | 'createdAt' | 'updatedAt'>
): Promise<BoardProject> {
  const state = await getAppState();
  const now = new Date().toISOString();
  const newProject: BoardProject = {
    ...project,
    id: `board_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    createdAt: now,
    updatedAt: now,
  };
  state.boardProjects.push(newProject);
  await localforage.setItem(STORAGE_KEY, state);
  return newProject;
}

export async function updateBoardProject(
  id: string,
  updates: Partial<BoardProject>
): Promise<BoardProject | null> {
  const state = await getAppState();
  const project = state.boardProjects.find(p => p.id === id);
  if (!project) return null;
  Object.assign(project, { ...updates, updatedAt: new Date().toISOString() });
  await localforage.setItem(STORAGE_KEY, state);
  return project;
}

export async function deleteBoardProject(id: string): Promise<boolean> {
  const state = await getAppState();
  const index = state.boardProjects.findIndex(p => p.id === id);
  if (index === -1) return false;
  state.boardProjects.splice(index, 1);
  await localforage.setItem(STORAGE_KEY, state);
  return true;
}

export async function getBoardProjects(): Promise<BoardProject[]> {
  const state = await getAppState();
  return state.boardProjects;
}

export async function getBoardProject(id: string): Promise<BoardProject | null> {
  const state = await getAppState();
  return state.boardProjects.find(p => p.id === id) || null;
}

// Clear all data
export async function clearAllData(): Promise<void> {
  await localforage.setItem(STORAGE_KEY, defaultState);
}

// Get statistics
export async function getStats() {
  const state = await getAppState();
  const pendingTodos = state.todos.filter(t => !t.done).length;
  const notesCount = state.notes.length;
  const lastBoard = state.boardProjects[state.boardProjects.length - 1];

  return {
    pendingTodos,
    notesCount,
    lastBoard: lastBoard ? lastBoard.name : null,
  };
}
