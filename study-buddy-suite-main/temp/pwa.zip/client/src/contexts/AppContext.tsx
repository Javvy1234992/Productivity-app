import React, { createContext, useContext, useEffect, useState } from 'react';
import { AppState, initializeStorage, getAppState, updateAppState } from '@/lib/storage';

interface AppContextType {
  appState: AppState | null;
  loading: boolean;
  refreshState: () => Promise<void>;
  updateState: (updates: Partial<AppState>) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [appState, setAppState] = useState<AppState | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      try {
        await initializeStorage();
        const state = await getAppState();
        setAppState(state);
      } catch (error) {
        console.error('Failed to initialize storage:', error);
      } finally {
        setLoading(false);
      }
    };

    init();
  }, []);

  const refreshState = async () => {
    try {
      const state = await getAppState();
      setAppState(state);
    } catch (error) {
      console.error('Failed to refresh state:', error);
    }
  };

  const updateState = async (updates: Partial<AppState>) => {
    try {
      const newState = await updateAppState(updates);
      setAppState(newState);
    } catch (error) {
      console.error('Failed to update state:', error);
    }
  };

  return (
    <AppContext.Provider value={{ appState, loading, refreshState, updateState }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
