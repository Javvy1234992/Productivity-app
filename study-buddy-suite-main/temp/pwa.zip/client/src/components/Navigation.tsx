import { useState } from 'react';
import { useLocation } from 'wouter';
import { Home, CheckSquare, Calendar, FileText, Palette, Menu, Trash2, HelpCircle, Brush } from 'lucide-react';
import { clearAllData } from '@/lib/storage';
import { useApp } from '@/contexts/AppContext';

/**
 * Navigation Component
 * Design: Minimalist top navigation bar with muted blue tones
 * - Persistent across all pages
 * - Neumorphic icons for visual interest
 * - Dropdown menu for settings
 */

export default function Navigation() {
  const [location, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const { updateState } = useApp();

  const navItems = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/todos', label: 'To-do', icon: CheckSquare },
    { path: '/calendar', label: 'Calendar', icon: Calendar },
    { path: '/notes', label: 'Notes', icon: FileText },
    { path: '/board', label: 'Board', icon: Brush },
  ];

  const isActive = (path: string) => location === path;

  const handleDeleteData = async () => {
    if (window.confirm('Are you sure you want to delete all data? This cannot be undone.')) {
      try {
        await clearAllData();
        await updateState({});
        setMenuOpen(false);
        setLocation('/');
      } catch (error) {
        console.error('Failed to delete data:', error);
      }
    }
  };

  const handleThemeToggle = async () => {
    const { appState } = require('@/contexts/AppContext').useApp();
    const newTheme = appState?.theme === 'light' ? 'dark' : 'light';
    await updateState({ theme: newTheme });
    setMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 flex items-center justify-between px-4 py-3 bg-[#c3ceda] border-b border-[#c3ceda] shadow-sm">
      {/* Logo/Brand */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
          <Palette className="w-5 h-5 text-accent-foreground" />
        </div>
        <span className="font-bold text-foreground hidden sm:inline">Productivity</span>
      </div>

      {/* Navigation Items */}
      <div className="flex items-center gap-1 flex-1 justify-center">
        {navItems.map(({ path, label, icon: Icon }) => (
          <button
            key={path}
            onClick={() => setLocation(path)}
            className={`nav-item ${isActive(path) ? 'active' : ''}`}
            aria-label={label}
            aria-current={isActive(path) ? 'page' : undefined}
          >
            <Icon className="w-5 h-5" />
            <span className="hidden sm:inline text-sm">{label}</span>
          </button>
        ))}
      </div>

      {/* Menu Button */}
      <div className="relative">
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="p-2 hover:bg-muted rounded-lg transition-colors"
          aria-label="Menu"
          aria-expanded={menuOpen}
        >
          <Menu className="w-5 h-5 text-foreground" />
        </button>

        {/* Dropdown Menu */}
        {menuOpen && (
          <div className="absolute right-0 mt-2 w-48 bg-card border border-border rounded-lg shadow-lg overflow-hidden z-50">
            <button
              onClick={handleThemeToggle}
              className="w-full px-4 py-2 text-left hover:bg-muted transition-colors flex items-center gap-2 text-foreground"
            >
              <Palette className="w-4 h-4" />
              Customisation
            </button>
            <button
              onClick={() => setMenuOpen(false)}
              className="w-full px-4 py-2 text-left hover:bg-muted transition-colors flex items-center gap-2 text-foreground"
            >
              <HelpCircle className="w-4 h-4" />
              Tutorial
            </button>
            <hr className="border-border" />
            <button
              onClick={handleDeleteData}
              className="w-full px-4 py-2 text-left hover:bg-destructive hover:text-destructive-foreground transition-colors flex items-center gap-2 text-foreground"
            >
              <Trash2 className="w-4 h-4" />
              Delete Data
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
